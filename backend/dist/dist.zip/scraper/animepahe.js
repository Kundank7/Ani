"use strict";
// @ts-nocheck
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnimePaheScraper = void 0;
const browser_1 = require("../utils/browser");
const axios_1 = __importDefault(require("axios"));
const cheerio = __importStar(require("cheerio"));
const BASE_URL = 'https://animepahe.pw';
const API_URL = 'https://animepahe.pw/api';
class AnimePaheScraper {
    browser = null;
    requestHeaders = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': BASE_URL,
    };
    EPISODE_FETCH_CONCURRENCY = 6;
    async waitForChallengeBypass(page, timeoutMs = 60000) {
        const startedAt = Date.now();
        while (Date.now() - startedAt < timeoutMs) {
            try {
                const challengeState = await page.evaluate(() => {
                    const title = String(document.title || '');
                    const bodyText = String(document.body?.innerText || '');
                    const normalized = `${title}\n${bodyText}`.toLowerCase();
                    const blocked = normalized.includes('checking your browser before accessing animepahe.com') ||
                        normalized.includes('ddos-guard');
                    return {
                        blocked,
                        title,
                    };
                });
                if (!challengeState.blocked) {
                    return true;
                }
            }
            catch {
                // Keep polling until timeout
            }
            await new Promise((resolve) => setTimeout(resolve, 2000));
        }
        return false;
    }
    async getBrowser() {
        if (!this.browser) {
            this.browser = await (0, browser_1.getBrowserInstance)();
        }
        return this.browser;
    }
    async fetchApiJson(url) {
        try {
            const response = await axios_1.default.get(url, {
                headers: this.requestHeaders,
                timeout: 10000,
                responseType: 'json',
            });
            return response.data ?? null;
        }
        catch (error) {
            return null;
        }
    }
    async fetchApiJsonWithCookies(url, cookieHeader, referer) {
        try {
            const response = await axios_1.default.get(url, {
                headers: {
                    ...this.requestHeaders,
                    ...(referer ? { Referer: referer } : {}),
                    ...(cookieHeader ? { Cookie: cookieHeader } : {}),
                },
                timeout: 15000,
                responseType: 'json',
            });
            return response.data ?? null;
        }
        catch (error) {
            return null;
        }
    }
    async close() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
        }
    }
    async search(query) {
        const searchUrl = `${API_URL}?m=search&q=${encodeURIComponent(query)}`;
        // Fast path: direct API call via axios (no browser spin-up)
        const apiResponse = await this.fetchApiJson(searchUrl);
        if (apiResponse && Array.isArray(apiResponse.data)) {
            return apiResponse.data.map((item) => ({
                id: item.id,
                session: item.session,
                title: item.title,
                url: `/anime/${item.session}`,
                poster: item.poster,
                status: item.status,
                type: item.type,
                episodes: item.episodes,
                year: item.year,
                score: item.score
            }));
        }
        // Fallback: Puppeteer path for protected responses
        const browser = await this.getBrowser();
        const page = await browser.newPage();
        await page.setUserAgent(this.requestHeaders['User-Agent']);
        try {
            console.log(`Searching: ${searchUrl}`);
            // Go directly to search URL
            await page.goto(searchUrl, { waitUntil: 'domcontentloaded', timeout: 15000 });
            // Wait for potential DDoS guard to resolve
            // We check if the body looks like JSON (starts with {)
            try {
                await page.waitForFunction(() => document.body.innerText.trim().startsWith('{'), { timeout: 8000 } // Give it 8s max to resolve
                );
            }
            catch (e) {
                console.log('Timeout waiting for JSON expectation, trying to parse anyway...');
            }
            const responseText = await page.evaluate(() => document.body.innerText);
            let response;
            try {
                response = JSON.parse(responseText);
            }
            catch (e) {
                console.error("Failed to parse search JSON:", responseText);
                return [];
            }
            console.log("Search Response:", JSON.stringify(response));
            if (response && response.data) {
                return response.data.map((item) => ({
                    id: item.id,
                    session: item.session,
                    title: item.title,
                    url: `/anime/${item.session}`,
                    poster: item.poster,
                    status: item.status,
                    type: item.type,
                    episodes: item.episodes,
                    year: item.year,
                    score: item.score
                }));
            }
            return [];
        }
        catch (error) {
            console.error('Error during search:', error);
            return [];
        }
        finally {
            await page.close();
        }
    }
    parseAnimeInfoFromHtml(html) {
        const sourceHtml = String(html || '');
        const normalizedHtml = sourceHtml.toLowerCase();
        if (normalizedHtml.includes('checking your browser before accessing animepahe.com') ||
            normalizedHtml.includes('ddos-guard') ||
            normalizedHtml.includes('why do i have to complete a captcha')) {
            return null;
        }
        const $ = cheerio.load(sourceHtml);
        const rawTitle = $('div.title-wrapper h1').first().text().trim() ||
            $('h1').first().text().trim() ||
            $('meta[property="og:title"]').attr('content')?.trim() ||
            $('title').text().replace(/\s*-\s*AnimePahe.*$/i, '').trim();
        const title = rawTitle && rawTitle.length % 2 === 0 && rawTitle.slice(0, rawTitle.length / 2) === rawTitle.slice(rawTitle.length / 2)
            ? rawTitle.slice(0, rawTitle.length / 2).trim()
            : rawTitle;
        if (!title)
            return null;
        const description = $('meta[property="og:description"]').attr('content')?.trim() ||
            $('.anime-synopsis').first().text().trim() ||
            $('div.anime-synopsis').first().text().trim() ||
            undefined;
        const poster = $('meta[property="og:image"]').attr('content')?.trim() ||
            $('img').filter((_, el) => String($(el).attr('src') || '').includes('/posters/')).first().attr('src')?.trim() ||
            undefined;
        const statsText = $('body').text();
        const episodesMatch = statsText.match(/Episodes:\s*(\d+)/i);
        const yearMatch = statsText.match(/Season:\s*[A-Za-z]+\s+(\d{4})/i) || statsText.match(/Aired:\s*.*?(\d{4})/i);
        const statusMatch = statsText.match(/Status:\s*([A-Za-z ]+)/i);
        const typeMatch = statsText.match(/Type:\s*([A-Za-z]+)/i);
        return {
            title,
            poster,
            description,
            status: statusMatch?.[1]?.trim(),
            type: typeMatch?.[1]?.trim(),
            episodes: episodesMatch?.[1] ? Number(episodesMatch[1]) : null,
            year: yearMatch?.[1] ? Number(yearMatch[1]) : null,
        };
    }
    async getAnimeInfo(session) {
        const animeUrl = `${BASE_URL}/anime/${session}`;
        try {
            const response = await axios_1.default.get(animeUrl, {
                headers: {
                    ...this.requestHeaders,
                    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                },
                timeout: 15000,
                responseType: 'text',
            });
            const html = String(response.data || '');
            const parsed = this.parseAnimeInfoFromHtml(html);
            if (parsed) {
                return parsed;
            }
        }
        catch (error) {
            // Fall through to browser-backed fetch.
        }
        {
            const browser = await this.getBrowser();
            const page = await browser.newPage();
            await page.setUserAgent(this.requestHeaders['User-Agent']);
            try {
                await page.setRequestInterception(true);
                page.on('request', (req) => {
                    const resourceType = req.resourceType();
                    if (['image', 'stylesheet', 'font', 'media'].includes(resourceType)) {
                        req.abort();
                    }
                    else {
                        req.continue();
                    }
                });
                await page.goto(animeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
                await this.waitForChallengeBypass(page);
                const html = await page.content();
                return this.parseAnimeInfoFromHtml(html);
            }
            catch (fallbackError) {
                console.error('Error getting AnimePahe info:', fallbackError);
                return null;
            }
            finally {
                await page.close();
            }
        }
    }
    async getEpisodes(animeSessionId, pageNum = 1) {
        const buildEpisodesApiUrl = (page) => `${API_URL}?m=release&id=${animeSessionId}&sort=episode_asc&page=${page}`;
        const animeUrl = `${BASE_URL}/anime/${animeSessionId}`;
        const mapApiEpisodes = (items) => items.map((item) => ({
            id: item.id.toString(),
            session: item.session,
            episodeNumber: item.episode,
            url: `/play/${animeSessionId}/${item.session}`,
            title: item.title,
            duration: item.duration,
            snapshot: item.snapshot
        }));
        const dedupeAndSortEpisodes = (items) => {
            const bySession = new Map();
            items.forEach((episode) => {
                const key = String(episode.session || episode.id || episode.episodeNumber);
                if (!key)
                    return;
                bySession.set(key, episode);
            });
            return [...bySession.values()].sort((a, b) => Number(a.episodeNumber) - Number(b.episodeNumber));
        };
        const getMinimumExpectedEpisodes = (lastPage) => {
            const normalizedLastPage = Number.isFinite(lastPage) && lastPage > 0 ? Math.floor(lastPage) : 1;
            return normalizedLastPage <= 1 ? 1 : ((normalizedLastPage - 1) * 30) + 1;
        };
        const isCompletePayload = (episodes, lastPage) => episodes.length >= getMinimumExpectedEpisodes(lastPage);
        const fetchRemainingPages = async (startPage, lastPage, fetcher) => {
            const results = [];
            for (let chunkStart = startPage; chunkStart <= lastPage; chunkStart += this.EPISODE_FETCH_CONCURRENCY) {
                const chunkPages = Array.from({ length: Math.min(this.EPISODE_FETCH_CONCURRENCY, lastPage - chunkStart + 1) }, (_, index) => chunkStart + index);
                const chunkResults = await Promise.all(chunkPages.map(async (currentPage) => ({
                    page: currentPage,
                    payload: await fetcher(currentPage)
                })));
                results.push(...chunkResults);
            }
            return results.sort((a, b) => a.page - b.page);
        };
        const fetchEpisodesViaApi = async () => {
            const first = await this.fetchApiJson(buildEpisodesApiUrl(pageNum));
            if (!first || !Array.isArray(first?.data))
                return null;
            const lastPage = Number(first?.last_page || 1);
            const pages = [first];
            const remaining = await fetchRemainingPages(pageNum + 1, lastPage, async (currentPage) => await this.fetchApiJson(buildEpisodesApiUrl(currentPage)));
            for (const { payload: next } of remaining) {
                if (!next || !Array.isArray(next?.data)) {
                    return {
                        episodes: dedupeAndSortEpisodes(pages.flatMap((payload) => Array.isArray(payload?.data) ? mapApiEpisodes(payload.data) : [])),
                        lastPage,
                        complete: false,
                    };
                }
                pages.push(next);
            }
            return {
                episodes: dedupeAndSortEpisodes(pages.flatMap((payload) => Array.isArray(payload?.data) ? mapApiEpisodes(payload.data) : [])),
                lastPage,
                complete: true,
            };
        };
        const fetchEpisodesViaSolvedBrowserCookies = async () => {
            const browser = await this.getBrowser();
            const page = await browser.newPage();
            await page.setUserAgent(this.requestHeaders['User-Agent']);
            try {
                await page.goto(animeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
                await this.waitForChallengeBypass(page, 70000);
                let first = null;
                let cookieHeader = '';
                const apiWaitStartedAt = Date.now();
                while (Date.now() - apiWaitStartedAt < 90000) {
                    const cookies = await page.cookies();
                    cookieHeader = cookies
                        .map((cookie) => `${cookie.name}=${cookie.value}`)
                        .join('; ')
                        .trim();
                    if (cookieHeader) {
                        first = await this.fetchApiJsonWithCookies(buildEpisodesApiUrl(pageNum), cookieHeader, animeUrl);
                        if (first && Array.isArray(first?.data)) {
                            break;
                        }
                    }
                    await new Promise((resolve) => setTimeout(resolve, 3000));
                }
                if (!first || !Array.isArray(first?.data))
                    return null;
                const lastPage = Number(first?.last_page || 1);
                const pages = [first];
                for (let currentPage = pageNum + 1; currentPage <= lastPage; currentPage += 1) {
                    let next = null;
                    for (let attempt = 0; attempt < 3; attempt += 1) {
                        const latestCookies = await page.cookies();
                        const latestCookieHeader = latestCookies
                            .map((cookie) => `${cookie.name}=${cookie.value}`)
                            .join('; ')
                            .trim();
                        next = await this.fetchApiJsonWithCookies(buildEpisodesApiUrl(currentPage), latestCookieHeader || cookieHeader, animeUrl);
                        if (next && Array.isArray(next?.data)) {
                            break;
                        }
                        await new Promise((resolve) => setTimeout(resolve, 2000));
                    }
                    if (!next || !Array.isArray(next?.data)) {
                        return {
                            episodes: dedupeAndSortEpisodes(pages.flatMap((payload) => Array.isArray(payload?.data) ? mapApiEpisodes(payload.data) : [])),
                            lastPage,
                            complete: false,
                        };
                    }
                    pages.push(next);
                }
                return {
                    episodes: dedupeAndSortEpisodes(pages.flatMap((payload) => Array.isArray(payload?.data) ? mapApiEpisodes(payload.data) : [])),
                    lastPage,
                    complete: true,
                };
            }
            catch (error) {
                return null;
            }
            finally {
                await page.close();
            }
        };
        const apiResult = await fetchEpisodesViaApi();
        if (apiResult?.episodes.length) {
            if (apiResult.complete && isCompletePayload(apiResult.episodes, apiResult.lastPage)) {
                return { episodes: apiResult.episodes, lastPage: apiResult.lastPage };
            }
            console.warn(`AnimePahe API returned partial episode list for ${animeSessionId}: ${apiResult.episodes.length}/${apiResult.lastPage} pages`);
        }
        const solvedCookieResult = await fetchEpisodesViaSolvedBrowserCookies();
        if (solvedCookieResult?.episodes.length) {
            if (solvedCookieResult.complete && isCompletePayload(solvedCookieResult.episodes, solvedCookieResult.lastPage)) {
                return { episodes: solvedCookieResult.episodes, lastPage: solvedCookieResult.lastPage };
            }
            console.warn(`AnimePahe solved-cookie episode fetch incomplete for ${animeSessionId}: ${solvedCookieResult.episodes.length}/${solvedCookieResult.lastPage} pages`);
        }
        // Puppeteer-first: AnimePahe's API is frequently challenge-protected for long-running series.
        const browser = await this.getBrowser();
        const page = await browser.newPage();
        await page.setUserAgent(this.requestHeaders['User-Agent']);
        try {
            console.log(`Fetching episodes via browser context: ${animeSessionId}`);
            // Optimize: Block heavy resources
            await page.setRequestInterception(true);
            page.on('request', (req) => {
                const resourceType = req.resourceType();
                if (['image', 'stylesheet', 'font', 'media'].includes(resourceType)) {
                    req.abort();
                }
                else {
                    req.continue();
                }
            });
            await page.goto(animeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
            await this.waitForChallengeBypass(page, 70000);
            const browserApiResponse = await page.evaluate(async (sessionId) => {
                const firstResponse = await fetch(`/api?m=release&id=${encodeURIComponent(sessionId)}&sort=episode_asc&page=1`, {
                    credentials: 'include',
                    headers: {
                        'Accept': 'application/json, text/plain, */*'
                    }
                });
                const firstText = await firstResponse.text();
                let firstParsed = null;
                try {
                    firstParsed = JSON.parse(firstText);
                }
                catch {
                    return {
                        ok: false,
                        first: {
                            ok: false,
                            status: firstResponse.status,
                            text: firstText
                        }
                    };
                }
                const first = {
                    ok: firstResponse.ok,
                    status: firstResponse.status,
                    parsed: firstParsed
                };
                if (!first.ok || !first.parsed?.data) {
                    return { ok: false, first };
                }
                const lastPage = Number(first.parsed.last_page || 1);
                const pages = [first.parsed];
                const concurrency = 6;
                for (let chunkStart = 2; chunkStart <= lastPage; chunkStart += concurrency) {
                    const chunkPages = Array.from({ length: Math.min(concurrency, lastPage - chunkStart + 1) }, (_, index) => chunkStart + index);
                    const chunkResults = await Promise.all(chunkPages.map(async (currentPage) => {
                        const nextResponse = await fetch(`/api?m=release&id=${encodeURIComponent(sessionId)}&sort=episode_asc&page=${currentPage}`, {
                            credentials: 'include',
                            headers: {
                                'Accept': 'application/json, text/plain, */*'
                            }
                        });
                        const nextText = await nextResponse.text();
                        let nextParsed = null;
                        try {
                            nextParsed = JSON.parse(nextText);
                        }
                        catch {
                            return {
                                page: currentPage,
                                ok: false,
                                failed: {
                                    ok: false,
                                    status: nextResponse.status,
                                    text: nextText
                                }
                            };
                        }
                        if (!nextResponse.ok || !nextParsed?.data) {
                            return {
                                page: currentPage,
                                ok: false,
                                failed: {
                                    ok: nextResponse.ok,
                                    status: nextResponse.status,
                                    parsed: nextParsed
                                }
                            };
                        }
                        return {
                            page: currentPage,
                            ok: true,
                            parsed: nextParsed
                        };
                    }));
                    const failed = chunkResults.find((entry) => !entry.ok);
                    if (failed) {
                        return {
                            ok: false,
                            first,
                            failedPage: failed.page,
                            failed: failed.failed
                        };
                    }
                    chunkResults
                        .sort((a, b) => a.page - b.page)
                        .forEach((entry) => {
                        if (entry.ok && entry.parsed)
                            pages.push(entry.parsed);
                    });
                }
                return { ok: true, pages, lastPage };
            }, animeSessionId);
            if (browserApiResponse?.ok && Array.isArray(browserApiResponse.pages)) {
                const episodes = dedupeAndSortEpisodes(browserApiResponse.pages.flatMap((payload) => Array.isArray(payload?.data) ? mapApiEpisodes(payload.data) : []));
                const lastPage = Number(browserApiResponse.lastPage || 1);
                if (isCompletePayload(episodes, lastPage)) {
                    return {
                        episodes,
                        lastPage
                    };
                }
                console.warn(`AnimePahe browser episode fetch incomplete for ${animeSessionId}: ${episodes.length}/${lastPage} pages`);
            }
            console.warn('Browser API episode fetch failed, falling back to HTML page scrape');
            return await this.getEpisodesFromHtml(page, animeSessionId);
        }
        catch (error) {
            console.error('Error getting episodes:', error);
            const htmlFallback = await this.getEpisodesFromHtml(null, animeSessionId);
            return htmlFallback.episodes.length > 0 ? htmlFallback : { episodes: [], lastPage: 1 };
        }
        finally {
            await page.close();
        }
    }
    async getEpisodesFromHtml(_page, animeSessionId) {
        const animeUrl = `${BASE_URL}/anime/${animeSessionId}`;
        const browser = await this.getBrowser();
        const page = await browser.newPage();
        await page.setUserAgent(this.requestHeaders['User-Agent']);
        try {
            await page.setRequestInterception(true);
            page.on('request', (req) => {
                const resourceType = req.resourceType();
                if (['image', 'stylesheet', 'font', 'media'].includes(resourceType)) {
                    req.abort();
                }
                else {
                    req.continue();
                }
            });
            await page.goto(animeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
            await this.waitForChallengeBypass(page, 70000);
            const extractEpisodesFromHtml = (html) => {
                const $ = cheerio.load(String(html || ''));
                const episodes = [];
                $('a.play').each((_, element) => {
                    const href = String($(element).attr('href') || '').trim();
                    if (!href.startsWith('/play/'))
                        return;
                    const title = $(element).text().trim().replace(/^Watch\s*-\s*/i, '').replace(/\s+Online$/i, '').trim();
                    const parts = href.split('/').filter(Boolean);
                    const episodeSession = parts[parts.length - 1];
                    const animeSession = parts[parts.length - 2];
                    if (!episodeSession || !animeSession)
                        return;
                    const epMatch = title.match(/(\d+(?:\.\d+)?)/);
                    const episodeNumber = epMatch ? Number(epMatch[1]) : NaN;
                    if (!Number.isFinite(episodeNumber))
                        return;
                    episodes.push({
                        id: episodeSession,
                        session: episodeSession,
                        episodeNumber,
                        url: href,
                        title: `Episode ${episodeNumber}`,
                    });
                });
                return episodes;
            };
            const dedupeAndSortEpisodes = (items) => {
                const bySession = new Map();
                items.forEach((episode) => {
                    const key = String(episode.session || episode.id || episode.episodeNumber);
                    if (!key)
                        return;
                    bySession.set(key, episode);
                });
                return [...bySession.values()].sort((a, b) => Number(a.episodeNumber) - Number(b.episodeNumber));
            };
            const extractLastPageFromHtml = (html) => {
                const $ = cheerio.load(String(html || ''));
                let lastPage = 1;
                $('[href*="page="], [data-page]').each((_, element) => {
                    const href = String($(element).attr('href') || '').trim();
                    const dataPage = String($(element).attr('data-page') || '').trim();
                    const hrefPageMatch = href.match(/[?&]page=(\d+)/i);
                    const value = Number(hrefPageMatch?.[1] || dataPage || 0);
                    if (Number.isFinite(value) && value > lastPage) {
                        lastPage = Math.floor(value);
                    }
                });
                return lastPage;
            };
            const html = await page.content();
            const lastPage = extractLastPageFromHtml(html);
            const pagesHtml = [html];
            if (lastPage > 1) {
                const remainingPages = await page.evaluate(async ({ sessionId, totalPages }) => {
                    const responses = [];
                    const concurrency = 4;
                    for (let chunkStart = 2; chunkStart <= totalPages; chunkStart += concurrency) {
                        const chunkPages = Array.from({ length: Math.min(concurrency, totalPages - chunkStart + 1) }, (_, index) => chunkStart + index);
                        const chunkResults = await Promise.all(chunkPages.map(async (currentPage) => {
                            try {
                                const response = await fetch(`/anime/${encodeURIComponent(sessionId)}?page=${currentPage}`, {
                                    credentials: 'include',
                                    headers: {
                                        'Accept': 'text/html,application/xhtml+xml'
                                    }
                                });
                                const nextHtml = await response.text();
                                return { page: currentPage, html: nextHtml };
                            }
                            catch {
                                return { page: currentPage, html: null };
                            }
                        }));
                        responses.push(...chunkResults);
                    }
                    return responses.sort((a, b) => a.page - b.page);
                }, { sessionId: animeSessionId, totalPages: lastPage });
                for (const result of remainingPages) {
                    if (typeof result?.html === 'string' && result.html.trim()) {
                        pagesHtml.push(result.html);
                    }
                }
            }
            const episodes = dedupeAndSortEpisodes(pagesHtml.flatMap((pageHtml) => extractEpisodesFromHtml(pageHtml)));
            return { episodes, lastPage };
        }
        catch (error) {
            console.error('Error getting AnimePahe episodes from HTML:', error);
            return { episodes: [], lastPage: 1 };
        }
        finally {
            await page.close();
        }
    }
    normalizePlayLinkUrl(url) {
        const raw = String(url || '').trim();
        if (!raw)
            return '';
        if (raw.startsWith('//'))
            return `https:${raw}`;
        if (raw.startsWith('/'))
            return `${BASE_URL}${raw}`;
        return raw;
    }
    extractPlayPageLinks(html) {
        const $ = cheerio.load(String(html || ''));
        const links = [];
        $('#resolutionMenu button, #resolutionMenu a, button[data-src][data-resolution], a[data-src][data-resolution]').each((_, element) => {
            const $element = $(element);
            const kwik = String($element.attr('data-src') || $element.attr('href') || '').trim();
            if (!kwik)
                return;
            links.push({
                kwik,
                quality: String($element.attr('data-resolution') || $element.text() || '').trim(),
                audio: String($element.attr('data-audio') || '').trim(),
            });
        });
        return links;
    }
    mapPlayPageLinks(links) {
        const seen = new Set();
        return links.flatMap((link) => {
            const kwikUrl = this.normalizePlayLinkUrl(link.kwik);
            if (!kwikUrl)
                return [];
            const quality = String(link.quality || '')
                .replace(/[^\d]/g, '')
                .trim() || '720';
            const audio = String(link.audio || 'sub').trim() || 'sub';
            const dedupeKey = `${kwikUrl}::${quality}::${audio.toLowerCase()}`;
            if (seen.has(dedupeKey))
                return [];
            seen.add(dedupeKey);
            return [{
                    quality,
                    audio,
                    provider: 'animepahe',
                    server: 'kwik',
                    url: kwikUrl,
                    isHls: false
                }];
        });
    }
    async getLinks(animeSession, episodeSession) {
        const fullUrl = `${BASE_URL}/play/${animeSession}/${episodeSession}`;
        try {
            const htmlResponse = await axios_1.default.get(fullUrl, {
                headers: {
                    ...this.requestHeaders,
                    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                },
                timeout: 15000,
                responseType: 'text',
            });
            const fastLinks = this.mapPlayPageLinks(this.extractPlayPageLinks(String(htmlResponse.data || '')));
            if (fastLinks.length > 0) {
                return fastLinks;
            }
        }
        catch {
            // Fall through to browser-backed page resolution.
        }
        const browser = await this.getBrowser();
        const page = await browser.newPage();
        await page.setUserAgent(this.requestHeaders['User-Agent']);
        const extractLinksFromPage = async () => {
            const liveLinks = await page.evaluate(() => {
                const elements = Array.from(document.querySelectorAll('#resolutionMenu button, #resolutionMenu a, button[data-src][data-resolution], a[data-src][data-resolution]'));
                return elements
                    .map((element) => ({
                    kwik: element.getAttribute('data-src') || element.getAttribute('href') || '',
                    quality: element.getAttribute('data-resolution') || element.textContent || '',
                    audio: element.getAttribute('data-audio') || '',
                }))
                    .filter((entry) => Boolean(entry.kwik));
            });
            if (liveLinks.length > 0) {
                return liveLinks;
            }
            return this.extractPlayPageLinks(await page.content());
        };
        try {
            await page.setRequestInterception(true);
            page.on('request', (req) => {
                const resourceType = req.resourceType();
                if (['image', 'stylesheet', 'font', 'media'].includes(resourceType)) {
                    req.abort();
                }
                else {
                    req.continue();
                }
            });
            for (let navigationAttempt = 0; navigationAttempt < 2; navigationAttempt += 1) {
                if (navigationAttempt === 0) {
                    await page.goto(fullUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
                }
                else {
                    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 });
                }
                await this.waitForChallengeBypass(page, 70000);
                for (let readAttempt = 0; readAttempt < 4; readAttempt += 1) {
                    const links = this.mapPlayPageLinks(await extractLinksFromPage());
                    if (links.length > 0) {
                        return links;
                    }
                    if (readAttempt === 0) {
                        try {
                            await page.waitForSelector('#resolutionMenu button[data-src], #resolutionMenu a[data-src]', { timeout: 5000 });
                            const waitedLinks = this.mapPlayPageLinks(await extractLinksFromPage());
                            if (waitedLinks.length > 0) {
                                return waitedLinks;
                            }
                        }
                        catch {
                            // Keep polling below.
                        }
                    }
                    await new Promise((resolve) => setTimeout(resolve, 1500 * (readAttempt + 1)));
                }
            }
            console.warn(`AnimePahe play page yielded no stream links for ${animeSession}/${episodeSession}`);
            return [];
        }
        catch (error) {
            console.error('Error getting AnimePahe links:', error);
            return [];
        }
        finally {
            await page.close();
        }
    }
    async resolveKwik(url) {
        const browser = await this.getBrowser();
        const page = await browser.newPage();
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        // Kwik needs referer
        await page.setExtraHTTPHeaders({
            'referer': 'https://kwik.cx/',
            'origin': 'https://kwik.cx'
        });
        try {
            await page.goto(url, { waitUntil: 'domcontentloaded' });
            // The direct link is usually inside a packed script.
            // We can wait for the page to evaluate it or extract and solve.
            // Let's try to find potential source from content first.
            const content = await page.content();
            // Logic to handle kwik's eval(p,a,c,k,e,d)
            // Or just wait for the video tag to appear?
            // Usually kwik loads a script that then creates the video/source.
            const directUrl = await page.evaluate(() => {
                // Try to find the script and execute a modified version to get the URL?
                // Actually, kwik's script usually sets a variable or just creates the player.
                // Let's try to extract it from the source code directly using regex if it's there.
                const scripts = Array.from(document.querySelectorAll('script'));
                for (const script of scripts) {
                    const text = script.textContent || '';
                    if (text.includes('eval(function(p,a,c,k,e,d)')) {
                        // This is the one. We could try to decode it, 
                        // but maybe it's already in a variable after execution?
                        // Let's check common variables.
                    }
                }
                // Often kwik has a "source" variable or similar in the window
                return window.source || document.querySelector('source')?.src || null;
            });
            if (directUrl)
                return directUrl;
            // If not found, use regex on the content
            const packedMatch = content.match(/eval\(function\(p,a,c,k,e,d\)\{.*\}\(.*\)\)/);
            if (packedMatch) {
                // We can't easily unpack in Node without a library, but we can try to evaluate it in the browser!
                const solved = await page.evaluate((packed) => {
                    try {
                        // Override eval to capture the result
                        let result = '';
                        const originalEval = window.eval;
                        window.eval = (s) => { result = s; return originalEval(s); };
                        originalEval(packed);
                        window.eval = originalEval;
                        return result;
                    }
                    catch (e) {
                        return null;
                    }
                }, packedMatch[0]);
                if (solved) {
                    const urlMatch = solved.match(/source=['"](.*?)['"]/);
                    if (urlMatch)
                        return urlMatch[1];
                }
            }
            return null;
        }
        catch (e) {
            return null;
        }
        finally {
            await page.close();
        }
    }
}
exports.AnimePaheScraper = AnimePaheScraper;
